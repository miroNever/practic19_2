package com.example.practica18_poleev

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView

class MainActivity2 : AppCompatActivity() {

    private lateinit var  Listview : ListView
    lateinit var backButton: Button
    lateinit var delButton: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        backButton = findViewById(R.id.back)
        delButton = findViewById(R.id.delbutton)

        Listview = findViewById(R.id.listview)

        val tickets = SheredPreferencesHelper.loadTickets(this)
        val ticketdata = tickets.map { "${it.title}\n" + "${it.descr}" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ticketdata)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        Listview.adapter = adapter

        backButton.setOnClickListener {

            val intent = Intent(this, Add_Case::class.java)
            startActivity(intent)
        }
        delButton.setOnClickListener {

            SheredPreferencesHelper.clearTickets(this)
            adapter.clear()
            adapter.notifyDataSetChanged()
        }

    }
}