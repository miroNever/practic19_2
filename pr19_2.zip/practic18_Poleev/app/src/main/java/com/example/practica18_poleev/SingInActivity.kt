package com.example.practica18_poleev

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.Gson

class SingInActivity : AppCompatActivity() {
    lateinit var but: Button
    lateinit var login : EditText
    lateinit var password: EditText
    lateinit var pref: SharedPreferences
    lateinit var ed : Editor
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_singin)
        but = findViewById(R.id.SingButton)
        login = findViewById(R.id.login)
        password = findViewById(R.id.password)
        pref = getPreferences(MODE_PRIVATE)
    }

    fun sing(view: View) {
        if(login.text.toString().isNotEmpty() && password.text.toString().isNotEmpty())
        {
            ed = pref.edit()
            val data = LoginPassword()
            data.Login = login.text.toString()
            data.Password = password.text.toString()

            ed.putString("LoginPassword", Gson().toJson(data))
            ed.apply()

            val intent = Intent(this,Add_Case:: class.java)
            startActivity(intent)
        }
        else{
            val alert = AlertDialog.Builder(this)
                .setTitle("Ошибка")
                .setMessage("У вас есть не заполненые поля")
                .setPositiveButton("Ok", null)
                .create()
                .show()
        }

    }

    fun datasing(view: View) {
        pref = getPreferences(MODE_PRIVATE)
        val alert = AlertDialog.Builder(this)
            .setTitle("Вставить данные?")
            .setMessage(pref.getString("login", "") + "\n" + pref.getString("password", ""))
            .setPositiveButton("Да"){_,_ ->
                login.setText(pref.getString("login", ""))
                password.setText(pref.getString("password", ""))
            }
            .setNegativeButton("Нет", null)
            .create()
            .show()
    }
}