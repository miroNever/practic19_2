package com.example.practica18_poleev

import android.annotation.SuppressLint
import android.app.backup.SharedPreferencesBackupHelper
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson

class Add_Case : AppCompatActivity() {

    lateinit var title: EditText
    lateinit var description : EditText
    lateinit var Next : Button
    lateinit var Back : Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_case)
        title = findViewById(R.id.title)
        description = findViewById(R.id.description)
        Next = findViewById(R.id.next)
        Back = findViewById(R.id.back)
        Next.setOnClickListener {

            if (title.text.isEmpty() && description.text.isEmpty()) {
                val i = Toast.makeText(this, "Заполните дело", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 0)
                i.show()
                return@setOnClickListener
            }
            val textTitle = title.text.toString()
            val textDescription = description.text.toString()
            val ticket = Ticket(textTitle, textDescription)
            val tickets = SheredPreferencesHelper.loadTickets(this).toMutableList()

            if (tickets.any { it.textTitle.contains(title.text) }) {
                val i = Toast.makeText(this, "Дело с такие названием уже есть!", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 0)
                i.show()
                return@setOnClickListener
            }

            tickets.add(ticket)
            SheredPreferencesHelper.saveTickets(this, tickets)

            val i = Toast.makeText(this, "Дело ${textTitle} добавлено", Toast.LENGTH_SHORT)
            i.setGravity(Gravity.TOP, 0, 0)
            i.show()

            title.text = null
            description.text = null
        }

        Back.setOnClickListener {

            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }
    }

}