package com.example.practica18_poleev

import android.content.ClipDescription

data class Ticket(val textTitle: String, val textDescription : String)