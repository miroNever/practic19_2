package com.example.practica18_poleev

data class Ticket(val title: String, val descr : String)